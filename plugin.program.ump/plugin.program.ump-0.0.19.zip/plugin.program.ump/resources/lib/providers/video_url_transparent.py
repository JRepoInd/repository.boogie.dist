import json

def run(hash,ump):
	return hash