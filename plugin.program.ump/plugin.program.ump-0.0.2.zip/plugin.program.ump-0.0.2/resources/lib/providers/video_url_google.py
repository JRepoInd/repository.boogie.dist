import re
import json

def run(hash,ump):
	hash=json.loads(hash)
	src = ump.get_page(hash["url"],"utf8",referer=hash["referer"])
	videos=re.findall('"file": "(.*?)", "label": "(.*?)"',src)
	opts={}
	for video in videos:
		opts[video[1]]=video[0]
	return opts