def run(hash,ump):
	return {"url":"http://redmp3.me/findfile/?id=%s"%hash}