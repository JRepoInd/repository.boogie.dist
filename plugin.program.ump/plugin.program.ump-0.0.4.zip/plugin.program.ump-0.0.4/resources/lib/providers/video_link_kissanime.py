import urllib2
import urllib
import json
import re
import time
import urlparse
from third import execjs
from unidecode import unidecode
			
domain="http://kissanime.com"
encoding="utf-8"


def return_links(name,mp,h,fs):
	parts=[{"url_provider_name":mp, "url_provider_hash":h}]
	prefix=""
	if not fs == "Varsayilan":
		prefix="[FS:%s]"%fs
	name="%s[HS:TR]%s" % (prefix,name)
	ump.add_mirror(parts,name)

def scrape_moviepage(url,fansub,name):
	pg=ump.get_page(domain+url,encoding)
	videos=re.findall("'#video','(.*?)','#video'.*?icon-play\"></i>(.*?)</a>",pg)
	for video in videos:
		up=unidecode(video[1].replace(" ","").lower())
		u=video[0]
		try:
			if up=="mail": 
				up="mailru"
				continue
				#skip mailru this provider is messed up
			elif up=="myvi":
				uphash=re.findall("embed/html/(.*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up=="odnoklassniki": 
				up="okru"
				uphash=re.findall("/videoembed/(.*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up=="sibnet":
				continue
				#skip this provider it uses m3u8.
				uphash=re.findall("videoid\=([0-9]*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up in ["cloudy","videohut","videoraj"]:
				uphash=re.findall("\?id\=(.*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up == "vk":
				up="vkext"
				hash=re.findall("\?vid\=(.*?)\"",ump.get_page(domain+u,encoding))[0]
				oid,video_id,embed_hash=hash.split("_")
				uphash="http://vk.com/video_ext.php?oid="+oid+"&id="+video_id+"&hash="+embed_hash
			elif up == "turkanime":
				hash=re.findall("(http\://www.schneizel.net/video/index.php\?vid\=.*?)\"",ump.get_page(domain+u,encoding))[0]
				uphash=json.dumps({"url":hash,"referer":"http://www.turkanime.tv/bolum/shingeki-no-kyojin-25-bolum-final&fansub=PeaceFansub&giris=OK&video=690863"})
				up="google"
			elif up == "dailymotion":
				#todo prepare a decoder
				uphash=re.findall("/video/(.*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up == "kiwi":
				uphash=re.findall("v2/(.*?)\"",ump.get_page(domain+u,encoding))[0]
			elif up == "meta":
				#todo this provider is messed up
				continue
				#todo prepare a decoder
				uphash=re.findall("iframe/(.*?)/",ump.get_page(domain+u,encoding))[0]
			else:
				print "Unknown URL Provider: %s"%up
				continue
		except IndexError:
			print "Turkanimetv changed regex for : %s, skipping"%up
			continue
		return_links(name,up,uphash,fansub)	
def dec(s):
	try:
		offset=1 if s[0]=='+' else 0
		return int(eval(s.replace('!+[]','1').replace('!![]','1').replace('[]','0').replace('(','str(')[offset:]))
	except:
		return

def get_page(*args,**kwargs):
	try:
		page=ump.get_page(*args,**kwargs)
	except urllib2.HTTPError, err:
		if err.code == 503:
			body=err.read()
			try:
				challenge = re.search(r'name="jschl_vc" value="(\w+)"', body).group(1)
				challenge_pass = re.search(r'name="pass" value="(.+?)"', body).group(1)
				builder = re.search(r"setTimeout\(function\(\){\s+(var t,r,a,f.+?\r?\n[\s\S]+?a\.value =.+?)\r?\n", body).group(1)
				builder = re.sub(r"a\.value =(.+?) \+ .+?;", r"\1", builder)
				builder = re.sub(r"\s{3,}[a-z](?: = |\.).+", "", builder)

			except Exception as e:
				print ("[!] Unable to parse Cloudflare anti-bots page. Try upgrading cloudflare-scrape, or submit "
					   "a bug report if you are running the latest version. Please read "
					   "https://github.com/Anorov/cloudflare-scrape#updates before submitting a bug report.\n")
				raise
			js = re.sub(r"[\n\\']", "", builder)
			d,k,m=re.findall(',\s(.*?)={"(.*?)":(.*?)}',builder)[0]
			ops=re.findall(d+"\."+k+"(.)\=(.*?)\;",builder)
			res=dec(m)
			for op in ops:
				res=eval("res"+op[0]+"dec('"+op[1]+"')")
#			print "."+str(res)+"."
#			if "Node" in  execjs.get().name:
#				js1="return require('vm').runInNewContext('%s');" % js
#			js1=js.replace("parseInt", "return parseInt")
#			a1=int(execjs.exec_(js))
			answer = str(res + len("kissanime.com"))
			time.sleep(4)
			kwargs["referer"]=args[0]
			args=list(args)
			args[0]="%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&pass=%s&jschl_answer=%s"%(domain,challenge,challenge_pass,answer)
			return ump.get_page(*args,**kwargs)

def run(ump):
	globals()['ump'] = ump
	i=ump.info
	is_serie="tvshowtitle" in i.keys() and not i["tvshowtitle"].replace(" ","") == ""
	if is_serie:
		name=i["tvshowtitle"]
	else:
		name=i["title"]

	query={"v":"1.0","q":'"%s" site:http://kissanime.com/Anime/ -inurl:Episode'%name}
	
	ump.add_log("kissanime is searching %s"%name)
	j=json.loads(ump.get_page("http://ajax.googleapis.com/ajax/services/search/web",encoding,query=query))
	results=j["responseData"]["results"]
	if len(results)<1:
		ump.add_log("kissanime can't find %s"%name)
		return None
	else:
		found=False
		print len(results)
		for result in results:
			if found: break
			depth=result["unescapedUrl"].replace("http://kissanime.com/Anime/","").split("/")
			if len(depth)>1:
				print "dismissed:"+result["unescapedUrl"]
				continue
			print result["unescapedUrl"]
			page=get_page(result["unescapedUrl"],encoding)
			namesdiv=re.findall('class="info">Other name\:</span>(.*?)\n',page)
			print namesdiv
			for div in namesdiv:
				names=re.findall('">(.*?)</a>',div)
				for name1 in names:
					if ump.is_same(name1,name):
						ump.add_log("kissanime found %s"%unidecode(name))
						found=True
						break
	return None

	if url is None:	
		ump.add_log("turkanimetv can't find any links for %s"%name)
		return None
	
	url=re.findall('"(icerik/bolumler.*?)"',ump.get_page(domain+url,encoding))[0]

	if not is_movie:
		bolumler=re.findall('<a href="(.*?)" class="btn".*?title=".*?([0-9]*?)\..*?">',ump.get_page(domain+url,encoding))
		url=None
		for bolum in bolumler:
			try:
				bid=int(bolum[1])
			except:
				continue
			if bid == i["absolute_number"]:
				ump.add_log("turkanimetv matched episode %dx%d:%s" % (i["season"],i["episode"],bid))
				url=bolum[0]
				break
	else:
		url=re.findall('<a href="(.*?)" class="btn"',ump.get_page(domain+url,encoding))
		if len(url)==1:
			url=url[0]
			ump.add_log("turkanimetv matched %s" % unidecode(anime[1]))
		else:
			url=None

	if url is None:	
		ump.add_log("turkanimetv can't find any links for %s"%name)
		return None

	fansubs=re.findall("'#video','(.*?)fansub=(.*?)&giris=OK','#video'",ump.get_page(domain+url,encoding))
	for fansub in fansubs:
		f=fansub[1]
		u=fansub[0]+"fansub="+fansub[1]+"&giris=OK"
		scrape_moviepage(u,f,name)
	if len(fansubs)==0:
		scrape_moviepage(url,"Varsayilan",name)